try {
    importScripts('./dist/background.bundle.js')
} catch (error) {
    console.error(error)
}
